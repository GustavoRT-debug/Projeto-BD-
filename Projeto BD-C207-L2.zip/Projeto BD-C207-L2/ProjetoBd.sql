drop database if exists trab;
create database trab;
use trab;

SET GLOBAL SQL_SAFE_UPDATES = 0;
SET GLOBAL log_bin_trust_function_creators = 1;

CREATE TABLE IF NOT EXISTS treinador (
  idtreinador INT NOT NULL AUTO_INCREMENT,
  nome_trei VARCHAR(50) NOT NULL,
  PRIMARY KEY (idtreinador)
  );

CREATE TABLE IF NOT EXISTS time (
  idtime INT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(50) NOT NULL,
  dirigente VARCHAR(50) NOT NULL,
  estadio VARCHAR(50) NULL DEFAULT NULL,
  treinador_idtreinador INT,
  PRIMARY KEY (idtime, treinador_idtreinador),
  CONSTRAINT fk_time_treinador
    FOREIGN KEY (treinador_idtreinador)
    REFERENCES treinador (idtreinador)
    ON DELETE CASCADE
    ON UPDATE CASCADE
    );

CREATE TABLE IF NOT EXISTS jogador (
  idjogador INT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(50) NOT NULL,
  idade INT NOT NULL,
  numero_camisa INT NOT NULL,
  empresario VARCHAR(50) NULL DEFAULT NULL,
  time_idtime INT,
  time_treinador_idtreinador INT,
  PRIMARY KEY (idjogador, time_idtime, time_treinador_idtreinador),
  CONSTRAINT fk_jogador_time1
    FOREIGN KEY (time_idtime , time_treinador_idtreinador)
    REFERENCES time (idtime , treinador_idtreinador)
    ON DELETE CASCADE
    ON UPDATE CASCADE
    );

CREATE TABLE IF NOT EXISTS posicao (
  idposicao INT NOT NULL AUTO_INCREMENT,
  nome_pos VARCHAR(50) NOT NULL,
  PRIMARY KEY (idposicao)
  );

CREATE TABLE IF NOT EXISTS jogador_has_posicao (
  jogador_idjogador INT NOT NULL,
  posicao_idposicao INT NOT NULL,
  PRIMARY KEY (jogador_idjogador, posicao_idposicao),
  CONSTRAINT fk_jogador_has_posicao_jogador1
    FOREIGN KEY (jogador_idjogador)
    REFERENCES jogador (idjogador)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_jogador_has_posicao_posicao2
    FOREIGN KEY (posicao_idposicao)
    REFERENCES posicao (idposicao)
    ON DELETE CASCADE
    ON UPDATE CASCADE
    );


INSERT INTO treinador(nome_trei) VALUES ('Rogerio Ceni'),('Jair ventura'),('Tite');
INSERT INTO time(nome, dirigente, estadio,treinador_idtreinador) VALUES ('Flamengo', 'Joao Cruz', 'Maracana', '1'),
('Corinthians', 'Neto', 'Arena Timao', '2'),('Palmeiras', 'Leila', 'Alianz Parque', '3');
INSERT INTO jogador(nome, idade, numero_camisa, empresario,time_idtime, time_treinador_idtreinador) VALUES ('Gabigol', '24', '9', 'Joel','1', '01'),
('Arrascaeta', '25', '14', 'Jair', '2', '02'),('Diego', '30', '10', 'Arnaldo', '3', '03');
INSERT INTO posicao(nome_pos) VALUES ('Atacante'),('Meio Campo'),('Goleiro');
INSERT INTO jogador_has_posicao() VALUES('1', '1'), ('2', '2');

select * from jogador;
select * from time;
select * from treinador;
select * from posicao;
select * from jogador_has_posicao;

 select * from jogador where idade > 24;
 update posicao set nome_pos = "zagueiro" where idposicao='3';
 delete from time where idtime = '3';
alter table jogador add data_nasc varchar(50) not null;
update jogador set data_nasc = '28/07/2000' where idjogador = '1';


DELIMITER $$
DROP FUNCTION IF EXISTS soma $$
CREATE FUNCTION soma(gols1 int, gols2 int) RETURNS int
BEGIN
	RETURN gols1 + gols2;
END $$
DELIMITER ;

select soma(2,4);
